<?php
session_start();
require('php/functions.php');
require('php/functions_forum.php');

if(isset($_SESSION['id'])) {
    require 'inc/header2.html';
    }else {
     require 'inc/header.html'; 
   
}
?>










<!DOCTYPE html>

<html>

    <head>

      
    </head>
      <link rel="stylesheet" href="ftp.css">

    <body>

     <div class="jumbotron text-center"><br>
              <h3>CALCULE DEBIT</h3>
  
</div>

<div id="c" class=" container">
  <div class="row">

    
       
       
                </div>
     







         
<?php
if(isset($_POST['ftp2']))
    {
// Création fichier test à transmettre, création du fichier destination, gestion droits
			echo shell_exec('dd if=/dev/zero of=/home/sid/Bureau/testUp.txt bs=100M count=1'); // bs=byte size
			echo shell_exec('sudo chmod o+w /home/sid/Bureau/testUp.txt');
			echo shell_exec('sudo touch /home/sid/Bureau/fich.txt');
			echo shell_exec('sudo chmod o+w /home/sid/Bureau/fich.txt');
			
		
 

			$ftp_server = "127.0.0.1";
			$ftp_user = "sid";
			$ftp_mdp = "sidou2017";
			
			
			// Mise en place d'une connexion
			$connexion = ftp_connect($ftp_server) or die("Impossible de se connecter au serveur $ftp_server"); 

			// Tentative d'identification
						
				if (@ftp_login($connexion, $ftp_user, $ftp_mdp)) {
					echo "<p  Connecté en tant que $ftp_user@$ftp_server</br>";
					ftp_pasv($connexion, true);
				} else {
					echo "Connexion impossible en tant que $ftp_user</br>";
				}
			

				// Récupération de la taille du $fichierLocal
				$taille = round(filesize('/home/sid/Bureau/testUp.txt')/1000, 3); // changer par ftp_size
				if ($taille != -1) {
					echo "La taille du fichier testUp.txt est de $taille ko</br>";
				} else {
					echo "Impossible de récupérer la taille du fichier</br>";
				}
				
				// Timestamp en millisecondes du début du script (en PHP 5)
				$debut = microtime(true);
				  
				// Tentative de téléchargement du $fichierServeur et sauvegarde dans le $fichierLocal
				if (ftp_get($connexion,"/home/sid/Bureau/fich.txt" , "/home/sid/Bureau/testUp.txt", FTP_BINARY)) { // chnager par ftp_get
					echo "Le fichier testUp.txt  a été télecharger avec succès</br>";
					// Timestamp en millisecondes de la fin du script
					$fin = microtime(true);
					 
					// Différence en millisecondes entre le début et la fin
					$temps = round($fin - $debut, 4);
					$vitesse = round($taille/$temps, 4);
					// affichage du résultat
					echo 'Upload du fichier en ' . $temps . ' secondes.</br>';
					echo 'Vitesse d\'upload : ' . $vitesse . ' Ko/s</br></br>';
					
					
					
				} else {
					echo "Il y a un problème d'upload</br>";
				}
				// Fermeture de la connexion
			ftp_close($connexion);

}

?>




  <!--SERVICES SECTION END-->

   <section id="clients-sec">
        <div class="container">
            <div class="row">
<div class="col-md-12">
    <img src="assets/img/clients.png" alt="" class="img-rounded img-responsive" />
</div>

               
            </div>
        </div>
    </section>


  </body>




</html>




