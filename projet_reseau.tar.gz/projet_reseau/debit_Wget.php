


<?php
 require('php/config.php');   
//session_start();
    if(isset($_POST['wget']) && !empty($_POST['wget']))
    {
         		if ($_POST['wget'] == "16")				
       			 {
        		   $cmd = "wget -o debit.txt http://test-debit.free.fr/16384.rnd && tail -n2 debit.txt| cut -d\"(\"  -d\" \" -f3 |sed 's/.\{1\}//' > speed";
            			$speed = passthru ($cmd);
            			shell_exec('rm -f *.rnd');
				$v = shell_exec('cat speed');
            			echo 'Vitesse  : ' . $v . ' MO/s</br></br>'; 
            exit();
        		}

       			 if ($_POST['wget'] == "32")
       			 { $cmd = "wget -o debit.txt http://test-debit.free.fr/32768.rnd && tail -n2 debit.txt| cut -d\"(\"  -d\" \" -f3 |sed 's/.\{1\}//' > speed";
       			$speed = passthru ($cmd);
            			shell_exec('rm -f *.rnd');
				$v = shell_exec('cat speed');
            			echo 'Vitesse  : ' . $v . ' MO/s</br></br>';      
       			 }
			if ($_POST['wget'] == "64")
        		{ $cmd = "wget -o debit.txt http://test-debit.free.fr/65536.rnd && tail -n2 debit.txt| cut -d\"(\"  -d\" \" -f3 |sed 's/.\{1\}//' > speed";
       			$speed = passthru ($cmd);
            			shell_exec('rm -f *.rnd');
				$v = shell_exec('cat speed');
            			echo 'Vitesse  : ' . $v . ' MO/s</br></br>';           
        		}
    }

?>



<!DOCTYPE html>

<html>

    <head>

      
    </head>
      <link rel="stylesheet" href="wget.css">

    <body>

     <div class="jumbotron text-center"><br>
              <h3>CALCULE DEBIT</h3>
  
</div>

<div id="c" class=" container">
  <div class="row">

    
       
       
                </div>
          <center>
          <div class="panel panel-info">
                    <div id="h" class="panel-heading">
                        <h3 class="panel-title">TEST AVEC WGET</h3>
                        <h4 class="panel-title">CHOISISSEZ UNE TAILLE PARMIS CELLE PROPOSE</h4>
                    </div>
                    <div id="c2" class="panel-body">
                        <div class="form-group">
                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-block btn-success" name="wget" value="16">Télécharger un fichier de taille 16MO</button>
                            </form> <br>
                             <form action="graphpp.php" method="POST" style="display: inline">
			     <button type="submit" class="btn btn-primary" name="ok" value="ok">dessiner son graphe</button>
                            </form> &nbsp
                            <br><br>
                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-block btn-success" name="wget" value="32">Télécharger un fichier de taille 32MO</button>
                            </form> <br>

                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-primary" name="ok" value="32">dessiner son graphe</button>
                            </form>&nbsp
<br><br>


                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-block btn-success" name="wget" value="64">Télécharger un fichier de taille 64MO</button>
                            </form>
                            <br>
                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-primary" name="wget" value="64">dessiner son graphe</button>
                            </form>&nbsp

 <br><br>

  </center>
  
  
  
  <div id="c1" class=" container">
  <div class="row">

    
       
       
                </div>
                 
          <center>
          <div class="panel panel-info">
                    <div id="h" class="panel-heading">
                        <h3 class="panel-title">quelques informations sur le WGET</h3>
                        
                    </div>
                    <div  class="panel-body">
                        
                          <p> 

<B>Wget</B> est un programme en ligne de commande non interactif de téléchargement de fichiers depuis le Web. Il supporte les protocoles <B>HTTP</B>, <B>HTTPS</B> et <B>FTP</B> ainsi que le téléchargement au travers des proxies <B>HTTP</B>.

<B>Wget</B> peut travailler en arrière-plan et ainsi vous permettre de lancer un téléchargement et de vous déconnecter du système ! Utile car il ne requiert pas d'action de l'utilisateur et vous permet d'effectuer ses tâches en arrière plan, ce qui peut être très utile pour les téléchargements de données nombreuses et lourdes. Vous pouvez ainsi changer de session et laisser <B>Wget</B> finir le travail !

Ce logiciel libre permet le simple téléchargement d'un fichier mais aussi la recopie en local de tout ou partie d'un site qui sera par la suite consultable hors-ligne. Point fort appréciable, <B>Wget</B> vous permet de reprendre un téléchargement échoué suite à divers problèmes (connexions instables ou très lentes etc…). Les nombreuses options de Wget en font un outil de téléchargement très puissant !
</p>

 <form action="http://www.computerhope.com/unix/wget.htm" target="http://www.computerhope.com/unix/wget.htm" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-info" name="ok" value="ok"><B>Lien d'explication</B></button>
                            </form>
  </center>

    <!--SERVICES SECTION END-->

   <section id="clients-sec">
        <div class="container">
            <div class="row">
<div class="col-md-12">
    <img src="assets/img/clients.png" alt="" class="img-rounded img-responsive" />
</div>

               
            </div>
        </div>
    </section>


  </body>




</html>


