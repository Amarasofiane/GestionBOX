<?php
session_start();
require('php/functions.php');
require('php/functions_forum.php');

if(isset($_SESSION['id'])) {
    require 'inc/header2.html';
    }else {
     require 'inc/header.html'; 
   
}
?>










<!DOCTYPE html>

<html>

    <head>

      
    </head>
      <link rel="stylesheet" href="ping.css">

    <body>

     <div class="jumbotron text-center"><br>
              <h3>CALCULE DEBIT</h3>
  
</div>


<?php
if(isset($_POST['ftp']))
    {

			echo shell_exec('dd if=/dev/zero of=/home/sid/Bureau/testUp.txt bs=100M count=1'); 
			echo shell_exec('sudo chmod o+w /home/sid/Bureau/testUp.txt');
			echo shell_exec('sudo touch /home/sid/Bureau/fich.txt');
			echo shell_exec('sudo chmod o+w /home/sid/Bureau/fich.txt');
			
		
 

			$ftp_server = "127.0.0.1";
			$ftp_user = "sid";
			$ftp_mdp = "sidou2017";
			
			
			// etablir la connexion
			$connexion = ftp_connect($ftp_server) or die("Impossible de se connecter au serveur $ftp_server"); 

			// Tentative d'identification
						
				if (@ftp_login($connexion, $ftp_user, $ftp_mdp)) {
					echo "Connecté en tant que $ftp_user@$ftp_server</br>";
					ftp_pasv($connexion, true);
				} else {
					echo "Connexion impossible en tant que $ftp_user</br>";
				}
			

				// Récupération de la taille du $testUp.txt
				$taille = round(filesize('/home/sid/Bureau/testUp.txt')/1000, 3); 
				if ($taille != -1) {
					echo "La taille du fichier testUp.txt est de $taille ko</br>";
				} else {
					echo "Impossible de récupérer la taille du fichier</br>";
				}
				
				// recuperation temps debut
				$debut = microtime(true);
				  
				// Tentative de téléchargement du $fich.txt et sauvegarde dans le $testUp.txt
				if (ftp_put($connexion,"/home/sid/Bureau/fich.txt" , "/home/sid/Bureau/testUp.txt", FTP_BINARY)) { 
					echo "Le fichier testUp.txt  a été écrit avec succès</br>";
					// temps
					$fin = microtime(true);
					 
					// Différence en millisecondes entre le début et la fin
					$temps = round($fin - $debut, 4);
					$vitesse = round($taille/$temps, 4);
					// affichage du résultat
					echo 'Upload du fichier en ' . $temps . ' secondes.</br>';
					echo 'Vitesse d\'upload : ' . $vitesse . ' Ko/s</br></br>';
					
					
					
				} else {
					echo "Il y a un problème d'upload</br>";
				}
				// Fermeture de la connexion
			ftp_close($connexion);

}

?>



 
