<?php
session_start();
require('php/functions.php');
require('php/functions_forum.php');

if(isset($_SESSION['id'])) {
    require 'inc/header2.html';
    }else {
     require 'inc/header.html'; 
   
}
?>

<?php
 require('php/config.php');   


?>



<!--MENU SECTION END-->
  <link rel="stylesheet" href="sec.css">
    <section class="headline-sec">
        <div class="overlay ">
            <h3 > PARE-FEU </h3>

        </div>
    </section>
   <!--SEARCH SECTION END-->
   <section id="services-sec">
        <div class="container">


           
            <div class="row text-center" >
            	   <div class="col-md-4">
                 
   <a href="https://mx.widgetsrus.com/iredadmin/create/user/style.dz"><i class="fa fa-users fa-5x icon-custom-1 color-1"></i>
</a>
    			<h3>CREER ADRESSE EMAIL</h3>
                        <p>
      
    	</p>
                </div>




	<div id="z1" class="col-md-4">
     			<a href="http://mx.widgetsrus.com/mail/"><i class="fa fa-envelope-square fa-5x icon-custom-1 color-1" ></i>
</a>
       <h3>SE CONNECTER</h3>
  	 <p>
     
    	</p>

</div>
               
             
           
        </div>

    </section>

    <!--SERVICES SECTION END-->
	   <section id="clients-sec">
        <div class="container">
            <div class="row">
<div class="col-md-12">
    <img src="assets/img/clients.png" alt="" class="img-rounded img-responsive" />
</div>

               
            </div>
        </div>
    </section>
