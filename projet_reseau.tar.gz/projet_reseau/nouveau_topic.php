<?php

session_start();
if(isset($_SESSION['id'])) {
   require 'inc/header2.html';
   } else {
    require 'inc/header.html'; 
   } 
   ?>

<?php

require('php/config.php'); /* Contient la connexion à la base de donnée $bdd */
require('php/functions.php'); /* Mes fonctions */

if(isset($_GET['categorie'])) {
   $get_categorie = htmlspecialchars($_GET['categorie']);
   $categorie = $pdo->prepare('SELECT * FROM f_categories WHERE id = ?');
   $categorie->execute(array($get_categorie));
   $cat_exist = $categorie->rowCount();
   if($cat_exist == 1) {
      $categorie = $categorie->fetch();
      $categorie = $categorie['nom'];
      $souscategories = $pdo->prepare('SELECT * FROM f_souscategories WHERE id_categorie = ? ORDER BY nom');
      $souscategories->execute(array($get_categorie));
      if(isset($_SESSION['id'])) {
         if(isset($_POST['tsubmit'])) {
            if(isset($_POST['tsujet'],$_POST['tcontenu'])) {
               $sujet = htmlspecialchars($_POST['tsujet']);
               $contenu = htmlspecialchars($_POST['tcontenu']);
               $souscategorie = htmlspecialchars($_POST['souscategorie']);
               $verify_sc = $pdo->prepare('SELECT id FROM f_souscategories WHERE id = ? AND id_categorie = ?');
               $verify_sc->execute(array($souscategorie,$get_categorie));
               $verify_sc = $verify_sc->rowCount();
               if($verify_sc == 1) {
                  if(!empty($sujet) AND !empty($contenu)) {
                     if(strlen($sujet) <= 70) {
                        if(isset($_POST['tmail'])) {
                           $notif_mail = 1;
                        } else {
                           $notif_mail = 0;
                        }
                        $ins = $pdo->prepare('INSERT INTO f_topics (id_createur, sujet, contenu, notif_createur, date_heure_creation) VALUES(?,?,?,?,NOW())');
                        $ins->execute(array($_SESSION['id'],$sujet,$contenu,$notif_mail));
                        
                        $lt = $pdo->query('SELECT id FROM f_topics ORDER BY id DESC LIMIT 0,1');
                        $lt = $lt->fetch();
                        $id_topic = $lt['id'];
                        $ins = $pdo->prepare('INSERT INTO f_topics_categories (id_topic, id_categorie, id_souscategorie) VALUES (?,?,?)');
                        $ins->execute(array($id_topic, $get_categorie, $souscategorie));
                     } else {
                        $terror = "Votre sujet ne peut pas dépasser 70 caractères";
                     }
                  } else {
                     $terror = "Veuillez compléter tous les champs";
                  }
               } else {
                  $terror = "Sous-catégorie invalide";
               }
            }
         }
      } else {
         $terror = "Veuillez vous connecter pour poster un nouveau topic";
      }
   } else {
      die('Catégorie invalide...');
   }
} else {
   die('Aucune catégorie définie...');
}

require('views/nouveau_topic.view.php'); /* Inclusion du fichier vue */
?>
</div>
</body>
  <!--SERVICES SECTION END-->
      <section id="clients-sec">
        <div class="container">
            <div class="row">
<div class="col-md-12">
    <img src="assets/img/clients.png" alt="" class="img-rounded img-responsive" />
</div>

               
            </div>
        </div>
    </section>
</html>
