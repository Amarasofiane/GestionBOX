#!/bin/bash
sudo cp /var/www/html/projet_reseau/resolv.conf /etc/resolv.conf
sudo service bind9 restart
exit 0
