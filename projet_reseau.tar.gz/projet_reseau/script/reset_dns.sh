#!/bin/bash
sudo cp /etc/network/interfaces ~/public_html/interfaces_dns.old
sudo cp ~/public_html/interfaces_dns.txt /etc/network/interfaces
sudo /etc/init.d/networking restart
exit 0