#!/bin/sh
sudo cp ~public_html/interfaces_ip.old /etc/network/interfaces 
sudo /etc/init.d/networking restart
exit 0
