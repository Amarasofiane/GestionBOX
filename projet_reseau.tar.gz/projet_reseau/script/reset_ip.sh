#!/bin/sh
sudo cp /etc/network/interfaces ~/public_html/interfaces_ip.old
sudo cp ~/public_html/interfaces_ip.txt /etc/network/interfaces
sudo /etc/init.d/networking restart
exit 0