#!/bin/bash
cp ~/public_html/parametres_dhcp.old /etc/dhcp/dhcpd.conf 
/etc/init.d/isc-dhcp-server restart
exit 0