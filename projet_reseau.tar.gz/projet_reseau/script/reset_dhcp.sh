#!/bin/bash
cp /etc/dhcp/dhcpd.conf ~/public_html/interfaces_dhcp.old
~/public_html/interfaces_dhcp.txt /etc/dhcp/dhcpd.conf
/etc/init.d/isc-dhcp-server restart
exit 0
