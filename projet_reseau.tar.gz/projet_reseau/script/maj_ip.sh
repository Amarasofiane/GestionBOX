#!/bin/bash

sudo cp /var/www/html/projet_reseau/interfaces_ip.txt /etc/network/interfaces

