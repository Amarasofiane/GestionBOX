

<?php
session_start();
require('php/functions.php');
require('php/functions_forum.php');

if(isset($_SESSION['id'])) {
	require 'inc/header2.html';
	} else {
	 require 'inc/header.html'; 
   
}

require('php/config.php'); /* Contient la connexion à la $bdd */
$categories = $pdo->query('SELECT * FROM f_categories ORDER BY nom');
$subcat = $pdo->prepare('SELECT * FROM f_souscategories WHERE id_categorie = ? ORDER BY nom');
?>
<!--MENU SECTION END-->
    <section class="headline-sec">
        <div class="overlay ">
            <h3 >forum <i class="fa fa-angle-double-right "></i></h3>

        </div>
    </section>
<?php
require('views/forum.view.php');
?>

    <!--SERVICES SECTION END-->
	   <section id="clients-sec">
        <div class="container">
            <div class="row">
<div class="col-md-12">
    <img src="assets/img/clients.png" alt="" class="img-rounded img-responsive" />
</div>

               
            </div>
        </div>
    </section>





