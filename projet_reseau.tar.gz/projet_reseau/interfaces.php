<?php
session_start();
require('php/functions.php');
require('php/functions_forum.php');

if(isset($_SESSION['id'])) {
    require 'inc/header2.html';
    } else {
     require 'inc/header.html'; 
   
}
?>
<!--MENU SECTION END-->
    <section class="headline-sec">
        <div class="overlay ">
            <h3 >INTERFACES <i class="fa fa-angle-double-right "></i></h3>

        </div>
    </section>
   <!--SEARCH SECTION END-->
    <section id="services-sec">
        <div class="container">


           
            <div class="row text-center" >
            	   <div class="col-md-4">
                     <a href="interface_ip.php"> <i class="fa fa-desktop fa-5x icon-custom-1 color-1"></i></a>
    <h3>configuration IP</h3>
                     <p>
       Pour configurer votre adresse ip.
       cela va modifier le fichier interfaces
       en vous attribuant l'adresse IP que vous avez renseigner
    </p>
                </div>
<div class="col-md-4">
     <a href="inter_dhcp.php"><i class="fa fa-database fa-5x icon-custom-1 color-1"></i></a>
    <h3>DHCP</h3>
    <p>
       DHCP, le protocole d'attribution dynamique des adresses (“Dynamic Host Configuration Protocol”)
    </p>

</div>
                <div class="col-md-4">
                     <a href="interface_dns.php"> <i class="fa fa-globe fa-5x icon-custom-1 color-1"></i></a>
    <h3>Domaine name server </h3>
                     <p>
   Configurer un serveur de noms (DNS) 
    </p>
                </div>
             
            </div>
        </div>
    </section>

    <!--SERVICES SECTION END-->
	   <section id="clients-sec">
        <div class="container">
            <div class="row">
<div class="col-md-12">
    <img src="assets/img/clients.png" alt="" class="img-rounded img-responsive" />
</div>

               
            </div>
        </div>
    </section>
