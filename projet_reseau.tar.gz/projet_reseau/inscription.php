<?php require 'inc/header.html'; ?>

<?php
require('php/config.php');
if(isset($_POST['forminscription'])) {
   $pseudo = htmlspecialchars($_POST['pseudo']);
   $mail = htmlspecialchars($_POST['mail']);
   $mail2 = htmlspecialchars($_POST['mail2']);
   $mdp = sha1($_POST['mdp']);
   $mdp2 = sha1($_POST['mdp2']);
   if(!empty($_POST['pseudo']) AND !empty($_POST['mail']) AND !empty($_POST['mail2']) AND !empty($_POST['mdp']) AND !empty($_POST['mdp2'])) {
      $pseudolength = strlen($pseudo);
      if($pseudolength <= 255) {
         if($mail == $mail2) {
            if(filter_var($mail, FILTER_VALIDATE_EMAIL)) {
               $reqmail = $pdo->prepare("SELECT * FROM membres WHERE mail = ?");
               $reqmail->execute(array($mail));
               $mailexist = $reqmail->rowCount();
               if($mailexist == 0) {
                  if($mdp == $mdp2) {
                     $insertmbr = $pdo->prepare("INSERT INTO membres(pseudo, mail, motdepasse) VALUES(?, ?, ?)");
                     $insertmbr->execute(array($pseudo, $mail, $mdp));
                     $erreur = "Votre compte a bien été créé ! <a href=\"index.php\">Me connecter</a>";
                  } else {
                     $erreur = "Vos mots de passes ne correspondent pas !";
                  }
               } else {
                  $erreur = "Adresse mail déjà utilisée !";
               }
            } else {
               $erreur = "Votre adresse mail n'est pas valide !";
            }
         } else {
            $erreur = "Vos adresses mail ne correspondent pas !";
         }
      } else {
         $erreur = "Votre pseudo ne doit pas dépasser 255 caractères !";
      }
   } else {
      $erreur = "Tous les champs doivent être complétés !";
   }
}
?>

 <!--MENU SECTION END-->
    <section class="headline-sec">
        <div class="overlay ">
            <h3 >INSCRIPTION <i class="fa fa-angle-double-right "></i></h3>

        </div>
    </section>
    <!--HOME SECTION END-->
    <section id="search-domain" >
        <div class="container">
            <div class="row">

                <div class="row">
                 <div class="col-md-6" >
                     <h2><strong> INSCRIPTION </strong></h2>
                     <br />
                    <h4>POUR GERER VOTRE BOX </h4>
                     <h4>VOUS DEVEZ VOUS INSCRIRE</h4>
                    
                </div>
                <div class="col-md-6" >
                    
                    <div class="alert alert-info" >
                        <div class="form-group">
                            <strong>INSCRIPTION</strong>
                                                    <form method="POST" action="">

                            <br />
                        <label></label>
                        <input type="text" class="form-control" name="pseudo" required="required" placeholder="Pseudo"/>
                            <label></label>
                        <input type="text" class="form-control" name="mail" required="required" placeholder="Mail"/>
                         <label></label>
                        <input type="text" class="form-control" name="mail2" required="required" placeholder="Confirmation mail"/>
                         <label></label>
                        <input type="password" class="form-control" name="mdp" required="required" placeholder="Mot de passe"/>
                         <label></label>
                        <input type="password" class="form-control" name="mdp2" required="required" placeholder=" Confirmation Mot de passe"/>
                       
                           <br />
                                    <button type="submit" name="forminscription" class="btn btn-success">inscription </button>
                            </div>
                       
                    </form>
                   <?php
         if(isset($erreur)) {
            echo '<font color="red">'.$erreur."</font>";
         }
         ?>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </section>
     <!--SEARCH SECTION END-->
    <section id="services-sec">
        <div class="container">
           
            <div class="row text-center" >
<div class="col-md-4">
    <i class="fa fa-database fa-5x icon-custom-1 color-1"></i>
    <h3>Hosting Spaces</h3>
    <p>
        Nunc at viverra risus. 
        In euismod quam ac dictum varius. 
        Nunc at viverra risus. 
        In euismod quam ac dictum varius.
    </p>

</div>
                <div class="col-md-4">
                     <i class="fa fa-globe fa-5x icon-custom-1 color-1"></i>
    <h3>Domain Register </h3>
                     <p>
        Nunc at viverra risus. 
        In euismod quam ac dictum varius. 
        Nunc at viverra risus. 
        In euismod quam ac dictum varius.
    </p>
                </div>
                <div class="col-md-4">
                     <i class="fa fa-desktop fa-5x icon-custom-1 color-1"></i>
    <h3>Web Designing</h3>
                     <p>
        Nunc at viverra risus. 
        In euismod quam ac dictum varius. 
        Nunc at viverra risus. 
        In euismod quam ac dictum varius.
    </p>
                </div>
            </div>
        </div>
    </section>
  
    
     <!--FOOTER SECTION END-->
    <div class="copy-txt">
         <div class="container">
        <div class="row">
<div class="col-md-12 set-foot" >
    &copy 2014 your domain | All rights reserved | Design by : <a href="http://www.binarytheme.com" target="_blank" style="color:#7C7C7C;">binarytheme.com</a> 
</div>
            </div>
                   </div>
    </div>
     <!-- COPY TEXT SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
