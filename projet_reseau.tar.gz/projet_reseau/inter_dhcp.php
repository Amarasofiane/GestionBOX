<?php
session_start();
require('php/functions.php');
require('php/functions_forum.php');

if(isset($_SESSION['id'])) {
    require 'inc/header2.html';
    } else {
     require 'inc/header.html'; 
   
}
?>

<?php
require('php/config.php');
if(isset($_POST['formdhcp'])) {

  //$ip = $_POST['ip'];
//$masque = $_POST['masque'];
//$subnet = $_POST['subnet'];
$debut = $_POST['debut'];
$fin = $_POST['fin'];

           echo'<div align="center">Mise à jour des paramêtres effectuée </br></br>';
    $fichier=fopen('interfaces_dhcp.txt','w+');
    
    
	fputs($fichier, 'default-lease-time 600');
    	fputs($fichier,"\n");
	fputs($fichier, 'max-lease-time 7200');
    	fputs($fichier,"\n");
	fputs($fichier, 'option subnet-mask ');
    	fputs($fichier,"\n");
	fputs($fichier, 'option broadcast-address 10.1.100.255');
    	fputs($fichier,"\n");
	fputs($fichier, 'option routers 10.120.0.1');
    	fputs($fichier,"\n");
	fputs($fichier, 'option domain-name-servers 10.1.100.41');
    	fputs($fichier,"\n");
	fputs($fichier, 'subnet 10.1.100.0 netmask 255.255.255.0     range '.$debut.' '.$fin.' ');
	fclose($fichier);)


}
?>
<!--MENU SECTION END-->
    <section class="headline-sec">
        <div class="overlay ">
            <h3 >DHCP <i class="fa fa-angle-double-right "></i></h3>

        </div>
    </section>
    
     <!--HOME SECTION END-->
     <center>
    <section id="search-domain" >
        <div class="container">
            <div class="row">

                <div class="row">
                    
                    <div class="alert alert-info" >
                        <div class="form-group">
                            <strong>CONFIGURATION DHCP</strong>
                            <br>
                                  <strong>CONFIGURATION ACTUEL DU FICHIER INTERFACES</strong>

                                                    <form method="POST" action="">
                                                        <?php
$text = file_get_contents("/etc/network/interfaces");
echo $text;
?> 

                            <br />

                   
                         <label></label>
                        <input type="text" class="form-control" name="debut" required="required" placeholder="Adresse ip du debut"/>
                         <label></label>
                        <input type="text" class="form-control" name="fin" required="required" placeholder="Adresse ip de fin"/>
                           <br />
                            <button type="submit" name="formdhcp" class="btn btn-success">CONFIGURER </button>
                            </div>
                       
                    </form>
           
                    <?php
                    $erreur='dhcp configurer';
         if(isset($_POST['formdhcp'])) {
            echo '<font color="red">'.$erreur."</font>";
         }
        
         ?>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </section>
    </center>
     <!--SERVICES SECTION END-->
       <section id="clients-sec">
        <div class="container">
            <div class="row">
<div class="col-md-12">
    <img src="assets/img/clients.png" alt="" class="img-rounded img-responsive" />
</div>

               
            </div>
        </div>
    </section>
