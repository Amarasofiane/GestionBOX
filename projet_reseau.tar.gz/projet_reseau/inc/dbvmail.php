<?php
    $pdo = new PDO('mysql:host=localhost;dbname=projet_reseau', 'amarasofiane1@outlook.fr', 'qmqrq2017');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
?>

    
