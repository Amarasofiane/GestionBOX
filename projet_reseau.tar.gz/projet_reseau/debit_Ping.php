

<?php
 if (isset($_POST['ping']) && !empty($_POST['ping']))
       {
            if ($_POST['ping'] == "16")
            {
                $cmd = shell_exec("ping -s 16000 -c 15 -a www.google.com > debit.txt| cut -d\"(\"  -d\" \" -f3 |sed 's/.\{1\}//' > speed ");
              $speed = passthru ($cmd);
            			shell_exec('rm -f *.rnd');
				$v = shell_exec('cat speed');
            			echo 'Vitesse  : ' . $v . ' MO/s</br></br>'; 
            }

	if ($_POST['ping'] == "32")
            {
                $cmd = shell_exec("ping -s 32384 -c 15 -a www.google.com > debit.txt| cut -d\"(\"  -d\" \" -f3 |sed 's/.\{1\}//' > speed ");
              $speed = passthru ($cmd);
            			shell_exec('rm -f *.rnd');
				$v = shell_exec('cat speed');
            			echo 'Vitesse  : ' . $v . ' MO/s</br></br>'; 
            }

	if ($_POST['ping'] == "64")
            {
                $cmd = shell_exec("ping -s 65536 -c 15 -a www.google.com > debit.txt| cut -d\"(\"  -d\" \" -f3 |sed 's/.\{1\}//' > speed ");
              $speed = passthru ($cmd);
            			shell_exec('rm -f *.rnd');
				$v = shell_exec('cat speed');
            			echo 'Vitesse  : ' . $v . ' MO/s</br></br>'; 
            }

	


}
 
 
 
 
 
?>



<!DOCTYPE html>

<html>

    <head>

      
    </head>
      <link rel="stylesheet" href="ping.css">

    <body>

     <div class="jumbotron text-center"><br>
              <h3>CALCULE DEBIT</h3>
  
</div>

<div id="c" class=" container">
  <div class="row">

    
       
       
                </div>
          <center>
          <div class="panel panel-info">
                    <div id="h" class="panel-heading">
                        <h3 class="panel-title">TEST AVEC PING</h3>
                        <h4 class="panel-title">CHOISISSEZ UNE TAILLE PARMIS CELLE PROPOSE</h4>
                    </div>
                    <div id="c2" class="panel-body">
                        <div class="form-group">
                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-block btn-success" name="ping" value="16">ping avec une taille  16MO</button>
                            </form> <br>
                             <form action="" method="POST" style="display: inline">
			     <button type="submit" class="btn btn-primary" name="ping" value="16">dessiner son graphe</button>
                            </form> 
                            <br><br>
                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-block btn-success" name="ping" value="32">ping avec une taille 32MO</button>
                            </form> <br>

                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn  btn-primary" name="ping" value="32">dessiner son graphe</button>
                            </form>
<br><br>


                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-block btn-success" name="ping" value="64">ping avec une taille 64MO</button>
                            </form>
                            <br>
                            <form action="" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-primary" name="ping" value="64">dessiner son graphe</button>
                            </form>
 <br><br>

  </center>
  
  
  
  <div id="c1" class=" container">
  <div class="row">

    
       
       
                </div>
                 
          <center>
          <div class="panel panel-info">
                    <div id="h" class="panel-heading">
                        <h3 class="panel-title">quelques informations sur le PING</h3>
                        
                    </div>
                    <div  class="panel-body">
                        
                          <p> 

<B>PING</B> est un programme en ligne de commande non interactif de téléchargement de fichiers depuis le Web. Il supporte les protocoles <B>HTTP</B>, <B>HTTPS</B> et <B>FTP</B> ainsi que le téléchargement au travers des proxies <B>HTTP</B>.


 <form action="https://openmaniak.com/fr/ping.php" target="https://openmaniak.com/fr/ping.php" method="POST" style="display: inline">
                                <button type="submit" class="btn btn-info" name="ok" value="ok"><B>Lien d'explication</B></button>
                            </form>
  </center>

  


  </body>




</html>

