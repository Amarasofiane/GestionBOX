<?php
session_start();
require('php/functions.php');
require('php/functions_forum.php');

if(isset($_SESSION['id'])) {
    require 'inc/header2.html';
    } else {
     require 'inc/header.html'; 
   
}
?>

<?php
require('php/config.php');
if(isset($_POST['formmsg'])) {


    $to = 'sidou_06@hotmail.com';
        $subject = 'coordonnees';


        $headers = 'From: ' . $_POST['email'] . ' ' . $_POST['nom'] . "\r\n";
        $sent_success = mail($to, $subject, $_POST["nom"]." ".$_POST["email"]." vous envoie ce message:\n".$_POST["msg"], $headers);
        if ($sent_success)
            {
                echo "Message envoyé avec succès :-)";
            }
        else
            {
                echo "Une erreur est survenue, veuillez essayer à nouveau... :-(";
            }

    


}
?> 
    <!--MENU SECTION END-->
    <section class="headline-sec">
        <div class="overlay ">
            <h3 >CONTACT <i class="fa fa-angle-double-right "></i></h3>

        </div>
    </section>
    <!--HOME SECTION END-->
    
    <section>
        <center>
        <div class="container">
            <div class="row">
                 
                <div class="col-md-6" >
                    
                    <div class="alert alert-info" >
                        <div class="form-group">
                            <strong>CONTACTER L'ASSISTANCE</strong>
                              <form method="POST" action="">
                            <br />

                        <label></label>
                        <input type="text" name="nom" class="form-control" placeholder="Nom"/>
                            <label></label>
                        <input type="text" name="email" class="form-control" placeholder=" Email" />
                            <label></label>
                           <textarea  name="msg" class="form-control" placeholder="Entrer votre message" rows="5" ></textarea>
                           <br />
                            <button type="submit" name="formmsg" class="btn btn-success">envoyer </button>
                            </div>
                              </form>

                    </div>
                   
                </div>
            </div>
        </div>
         </center>
    </section>
    
    <section id="footer-sec" >
        <div class="container">
            <div class="row">

                
                <div class="col-md-4">
      <h4>SOCIAL LINKS</h4>
                    <div class="social-links">

                    
                    <a href="#" > <i class="fa fa-facebook fa-2x" ></i></a>
                         <a href="#" > <i class="fa fa-twitter fa-2x" ></i></a>
                         <a href="#" > <i class="fa fa-linkedin fa-2x" ></i></a>
                         <a href="#" > <i class="fa fa-google-plus fa-2x" ></i></a>
                         <a href="#" > <i class="fa fa-github fa-2x" ></i></a>
                         <a href="#" > <i class="fa fa-digg fa-2x" ></i></a>
                         <a href="#" > <i class="fa fa-dropbox fa-2x" ></i></a>
                   </div>

</div>
               
            </div>
               
        </div>
    </section>
     <!--FOOTER SECTION END-->
    <div class="copy-txt">
         <div class="container">
        <div class="row">
<div class="col-md-12 set-foot" >
    &copy 2014 your domain | All rights reserved | Design by : <a href="http://www.binarytheme.com" target="_blank" style="color:#7C7C7C;">binarytheme.com</a> 
</div>
            </div>
                   </div>
    </div>
     <!-- COPY TEXT SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    
</body>
</html>
