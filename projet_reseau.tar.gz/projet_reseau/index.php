<?php
session_start();

require('php/config.php');
if(isset($_POST['formconnexion'])) {
   $mailconnect = htmlspecialchars($_POST['mailconnect']);
   $mdpconnect = sha1($_POST['mdpconnect']);
   if(!empty($mailconnect) AND !empty($mdpconnect)) {
      $requser = $pdo->prepare("SELECT * FROM membres WHERE mail = ? AND motdepasse = ?");
      $requser->execute(array($mailconnect, $mdpconnect));
      $userexist = $requser->rowCount();
      if($userexist == 1) {
         $userinfo = $requser->fetch();
         $_SESSION['id'] = $userinfo['id'];
         $_SESSION['pseudo'] = $userinfo['pseudo'];
         $_SESSION['mail'] = $userinfo['mail'];
         header("Location: interfaces.php?id=".$_SESSION['id']);
      } else {
         $erreur = "Mauvais mail ou mot de passe !";
      }
   } else {
      $erreur = "Tous les champs doivent être complétés !";
   }
}
?>


<?php require 'inc/header.html'; ?>

    <!--MENU SECTION END-->
    <section id="home-sec">
        <div class="overlay text-center">
            <h1 >PROJET RESEAU: LA BOX</h1>
            <hr class="hr-set"/>

             <MARQUEE bgcolor="404040" WIDTH="50%" DIRECTION="LEFT" behavior="alternate"> CREATION D'UNE BOX POUR LA GESTION D'UN RESEAU </MARQUEE>
        </div>
    </section>
    <!--HOME SECTION END-->
    <section id="search-domain" >
        <div class="container">
            <div class="row">

                <div class="row">
                 <div class="col-md-6" >
                     <h2><strong> LaBox </strong></h2>
                     <br />
                    <h4>Pour configurer votre box</h4>
                     <h4>veuiller vous connectez</h4>
                     <br />
                    
                </div>
                <div class="col-md-6" >
                    
                    <div class="alert alert-info" >
                        <div class="form-group">
                            <strong>CONNECTION</strong>
                                                    <form method="POST" action="">

                            <br />
                        <label></label>
                        <input type="text" class="form-control" name="mailconnect" required="required" placeholder="Email"/>
                            <label></label>
                        <input type="password" class="form-control" name="mdpconnect" required="required" placeholder="Mot de passe"/>
                       
                           <br />
                            <button type="submit" name="formconnexion" class="btn btn-success">CONNECTION </button>
                            </div>
                 <a href="inscription.php">S'incrire?</a>
                       
                    </form>
                    <?php
         if(isset($erreur)) {
            echo '<font color="red">'.$erreur."</font>";
         }
         ?>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </section>
     <!--SEARCH SECTION END-->
    <section id="services-sec">
        <div class="container">
           
            <div class="row text-center" >
<div class="col-md-4">
    <i class="fa fa-database fa-5x icon-custom-1 color-1"></i>
    <h3>DHCP</h3>
    <p>
          DHCP, le protocole d'attribution dynamique des adresses (“Dynamic Host Configuration Protocol”)

    </p>

</div>
                <div class="col-md-4">
                     <i class="fa fa-globe fa-5x icon-custom-1 color-1"></i>
    <h3>Domaine name server </h3>
                     <p>
        Configurer un serveur de noms (DNS) 

    </p>
                </div>
                <div class="col-md-4">
                     <i class="fa fa-desktop fa-5x icon-custom-1 color-1"></i>
    <h3>configuration IP</h3>
                     <p>
          Pour configurer votre adresse ip.
       cela va modifier le fichier interfaces
       en vous attribuant l'adresse IP que vous avez renseigner
    </p>
                </div>
            </div>
        </div>
    </section>
  
    
     <!--FOOTER SECTION END-->
    <div class="copy-txt">
         <div class="container">
        <div class="row">
<div class="col-md-12 set-foot" >
    &copy 2014 your domain | All rights reserved | Design by : <a href="http://www.binarytheme.com" target="_blank" style="color:#7C7C7C;">binarytheme.com</a> 
</div>
            </div>
                   </div>
    </div>
     <!-- COPY TEXT SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
