<?php
session_start();
require('php/functions.php');
require('php/functions_forum.php');

if(isset($_SESSION['id'])) {
    require 'inc/header2.html';
    }else {
     require 'inc/header.html'; 
   
}
?>





<!--MENU SECTION END-->
    <section class="headline-sec">
        <div class="overlay ">
            <h3 > TEST DE DEBIT <i class="fa fa-angle-double-right "></i></h3>

        </div>
    </section>
   <!--SEARCH SECTION END-->
    <section id="services-sec">
        <div class="container">


           
            <div class="row text-center" >
            	   <div class="col-md-4">
                     <a href="debit_Ping.php"> <i class="fa fa-area-chart fa-5x icon-custom-1 color-1"></i></a>
    <h3>TEST AVEC PING</h3>
                     <p>
      <B>WGET</B> est un programme en ligne de commande non interactif de téléchargement de fichiers depuis le Web. Il supporte les protocoles <B>HTTP</B>, <B>HTTPS</B> et <B>FTP</B> ainsi que le téléchargement au travers des proxies <B>HTTP</B>.
    </p>
                </div>
<div class="col-md-4">
     <a href="debit_Wget.php"><i class="fa fa-signal fa-5x icon-custom-1 color-1"></i></a>
    <h3>TEST AVEC WGET</h3>
    <p>
      <B>PING</B> est un programme en ligne de commande non interactif de téléchargement de fichiers depuis le Web. Il supporte les protocoles <B>HTTP</B>, <B>HTTPS</B> et <B>FTP</B> ainsi que le téléchargement au travers des proxies <B>HTTP</B>.
    </p>

</div>
                <div class="col-md-4">
                     <a href="debit_ftp_choix.php"> <i class="fa fa-line-chart fa-5x icon-custom-1 color-1"></i></a>
    <h3>TEST AVEC FTP </h3>
                     <p>
  
    </p>
                </div>
             
            </div>
        </div>
    </section>

    <!--SERVICES SECTION END-->
	   <section id="clients-sec">
        <div class="container">
            <div class="row">
<div class="col-md-12">
    <img src="assets/img/clients.png" alt="" class="img-rounded img-responsive" />
</div>

               
            </div>
        </div>
    </section>
