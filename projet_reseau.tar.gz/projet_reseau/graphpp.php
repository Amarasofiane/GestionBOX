<?php

require_once ('jpgraph/src/jpgraph.php');
require_once ('jpgraph/src/jpgraph_line.php');
require_once ('jpgraph/src/jpgraph_error.php');


//require_once ('../jpgraph/src/jpgraph.php');
//require_once ('../jpgraph/src/jpgraph_line.php');

$datay1 = array(0,3,5,12,15,18,22,36,37,41);
$datay2 = array(0,2,3,8,10,12,18,25,40,10);
//$bdd = new PDO('mysql:host=127.0.0.1;dbname=box', 'root', 'tp2016');
//$select = $bdd->query("SELECT * FROM `debit`");


// Setup the graph
$graph = new Graph(960,600);
//$graph->ClearTheme(); 
$graph->title->Set('Historique Debit');
$graph->title->SetFont(FF_FONT1,FS_BOLD);
$graph->SetScale('intlin');
$graph->SetMarginColor('white');
$graph->SetBox();
//$graph->img->SetAntialiasing();

//$graph->SetGridDepth(DEPTH_FRONT);
$graph->ygrid->SetColor('gray@0.7');

// Line plot 1
$p1 = new LinePlot($datay1);
$p1->SetColor('black@0.4');
$p1->SetWeight(3);
$p1->mark->SetType(MARK_SQUARE);
$p1->mark->SetColor('orange@0.5');
$p1->mark->SetFillColor('orange@0.3');
$graph->Add($p1);

// Line plot 2
$p2 = new LinePlot($datay2);
$p2->SetColor('red@0.4');
$p2->SetWeight(3);
$p2->mark->SetType(MARK_SQUARE);
$p2->mark->SetColor('red@0.1');
$p2->mark->SetFillColor('red@0.3');
$graph->Add($p2);

// legende
$p1->SetColor("#0000CD");
$p1->SetLegend("FTP");

$p2->SetColor("#8B008B");
$p2->SetLegend("SSH");

// Output line
$graph->Stroke();
?>
